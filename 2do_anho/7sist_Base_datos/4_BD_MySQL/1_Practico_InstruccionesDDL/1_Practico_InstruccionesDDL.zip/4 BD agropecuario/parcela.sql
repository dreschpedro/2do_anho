CREATE TABLE parcela (
id_parcela INT NOT NULL,
superficie INT DEFAULT NULL,
alambrado VARCHAR (10) DEFAULT NULL,
bebederos INT DEFAULT NULL,
PRIMARY KEY (id_parcela)
)