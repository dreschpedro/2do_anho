CREATE TABLE cuenta (
num_cuenta int NOT NULL AUTO_INCREMENT,
saldo_cuenta INT NOT NULL,
tipo_intereses VARCHAR(10),
PRIMARY KEY (num_cuenta)
)