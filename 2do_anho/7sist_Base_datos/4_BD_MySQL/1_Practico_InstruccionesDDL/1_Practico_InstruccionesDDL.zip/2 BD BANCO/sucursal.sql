CREATE TABLE sucursal(
cod_sucursal INT NOT NULL AUTO_INCREMENT,
cuidad VARCHAR(30) NOT NULL,
PRIMARY KEY (cod_sucursal)
)