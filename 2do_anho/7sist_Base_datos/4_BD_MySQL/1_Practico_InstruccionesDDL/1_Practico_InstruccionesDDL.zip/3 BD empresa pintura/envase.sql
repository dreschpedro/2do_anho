CREATE TABLE envase (
id_envase INT NOT NULL AUTO_INCREMENT,
tipo_envase VARCHAR(15) NOT NULL,
capacidad_envase INT NOT NULL,
PRIMARY KEY (id_envase)
)